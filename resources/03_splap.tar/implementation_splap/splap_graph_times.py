#!/usr/bin/python
# -*- coding: utf-8 -*-

from lxml import etree
import sys
import time, datetime
import matplotlib.pyplot as plt
import numpy as np
import xml.etree.ElementTree
from os import listdir
from os.path import isfile, join

excludes_list = []
featureP = ""


def debug(text):
    """
    Debug function. The text is shown into the std output stream.

    @param text : Not empty
    @rtype text : String for debugging
    """
    print "{0}".format(text)



warnings = []
prev = []
def add_warning(tt,old,new):
    global warnings
    warnings.append((tt,list(old),list(new)))

def reduce (l):
    m = set(map(frozenset,l))
    l = list(map(list,m))
                
def compute_denotational(root):
    """
    This function defines the denotational semantics for a fodaAT term.
    @param root: not null
    @rtype root: xml element
    """
    global prev
    #print "computing {0}".format(root.tag)

    result = []
    if(root.tag=="xml"):
        #initial tag
        for i in root.iterchildren():
            result.append(compute_denotational(i))
    elif(root.tag=="checkmark"):
        #checkmark rule
        return [[]]
    elif(root.tag=="mandatory_feature"):
        feature = root.get("name")
        
        for i in root.iterchildren():
            computation = compute_denotational(i)
            result.extend(computation)
        
        for i in result:

            if feature == featureP:
                i.append(feature)        #Agregamos el feature a cada elemento de la lista de result...
            else:
                if "*" not in i:
                   i.append("*")

        return result


    elif(root.tag=="optional_feature"):
        feature = root.get("name")
        result = []
        for i in root.iterchildren():
            computation = compute_denotational(i)
            result.extend(computation)
            #print result
        for i in result:
            if feature == featureP:
                i.append(feature)        #Agregamos el feature a cada elemento de la lista de result...
            else:
                if "*" not in i:
                   i.append("*")

        result.append([])


    elif(root.tag=="paralel"):
        #l = set()
 
        
        for i in root.iterchildren():
            compute = compute_denotational(i)
            #if compute not in val:
            if result == []:
                result = compute
                reduce(result)
            else:
                varx = []#list(result)
                k = 0
                reduce(result)
                reduce(compute)
            #    print len(result)
            #    print len(compute)
                for i in result:
                    for j in compute:
                        #if j not in result:
                        #print k
                        k = k+1
                        new = list(i)
                        new.extend(j)                          
                        varx.append(new)
                if varx !=[]:
                    result = varx
                lst2=[]
                [lst2.append(key) for key in result if key not in lst2]
                result = lst2
        
            
    elif(root.tag=="choose_1"):
        for i in root.iterchildren():
            resaux = compute_denotational(i)
            for j in resaux:
                result.append(j)
        m = map(frozenset,result)
        result = list(map(list,m))

    elif(root.tag =="requires"):
        #print "Requires"
        feat1 = root.get("feature_1")
        feat2 = root.get("feature_2")
        for i in root.iterchildren():
            resaux = compute_denotational(i)
            for j in resaux:
                if feat1 in j and feat2 not in j:
                    j.append(feat2)
                result.append(j)
        if prev != [] and prev.sort() == result.sort():
            add_warning(feat1 + " requires " + feat2,prev,result)
        prev = list(result)


    elif (root.tag=="excludes"):
        #print "Excludes"
        feat1 = root.get("feature_1")
        feat2 = root.get("feature_2")
        global excludes_list
        excludes_list.append((feat1,feat2))
        for i in root.iterchildren():
            resaux = compute_denotational(i)
            for j in resaux:
                if feat1 not in j or feat2 not in j:
                    result.append(j)
        if prev != [] and prev.sort() == result.sort():
            add_warning(feat1+" excludes "+feat2,prev,result)

        prev = list(result)

    
    if (result == []):
        debug("Error tag {0} not processed".format(root.tag))

    #
    #m = set(map(frozenset,result))
    #return list(map(list,m))
    return result
                
def reduce(l):
    global excludes_list
    r = []
    for (feat1,feat2) in excludes_list:
        for j in l:
            if feat1 not in j or feat2 not in j:
                r.append(j)
                
    l = list(r)
                

def run(file,fea):
    """
    Main function
    """
    global featureP
    
    name = file
    featureP = fea

    xml = etree.parse(name)
    start_time = datetime.datetime.now()
    results = compute_denotational(xml.getroot())
    end_time = datetime.datetime.now()
    exec_time = end_time - start_time
    elapsed_ms = (exec_time.days * 86400000) + (exec_time.seconds * 1000) + (exec_time.microseconds / 1000)
    a =float(sum(x.count(featureP) for x in results[0]))
    b =float(len(results[0]))

    return {'prob': a/b, 'time': elapsed_ms}

def main():

    times = []

    onlyfiles = [f for f in listdir('DATA_SPLAP/') if isfile(join('DATA_SPLAP/', f))]
    for fai in onlyfiles:
        if fai.endswith(".xml"):
            source = 'DATA_SPLAP/'+fai
            e = xml.etree.ElementTree.parse(source).getroot()
            for featureP in list(e.iter()):
                if featureP.tag == 'mandatory_feature' or featureP.tag == 'optional_feature':
                    result = run(source, featureP.get('name'))
                    times.append(result['time'])
            x = np.array(range(1, len(times)+1))
            y = np.array(times)
            min = np.min(y)
            max = np.max(y)
            avg = np.mean(y)
            fig, ax = plt.subplots()
            #fit = np.polyfit(x, y, deg=1)
            #ax.plot(x, fit[0] * x + fit[1], color='red', label="estimado")
            ax.scatter(x, y, color='blue', s=5, label="medido")
            #fig.show()
            extra = plt.scatter(0, 0, s=1, c='w', edgecolor='none', linewidth=0)
            plt.legend([extra, extra, extra], ("Min: "+str(min), "Max: "+str(max), "Avg: "+str(avg)),scatterpoints = 1, handlelength=0.001, borderpad=0.4, labelspacing=0.2)
            plt.axis([-10, len(times)+10, min-10, max+10])  # Put in side your range [xmin,xmax,ymin,ymax], like ax.axis([-5,5,-5,200])
            plt.xlabel(unicode('Feature number', "utf-8"))
            plt.ylabel(unicode('Time to calculate the probability (milliseconds)', "utf-8"))
            plt.savefig(source+'.time.eps', format='eps')
           # plt.show()


if __name__ == "__main__":
    main()
