#!/usr/bin/python
# -*- coding: utf-8 -*-
   
from lxml import etree
import xml.etree.ElementTree
import sys
featureP = ""


def splap(root):
    """
    This function defines the denotational semantics for a fodaAT term.
    @param root: not null
    @rtype root: xml element
    """
    result = []
    if(root.tag=="xml"):
        for i in root.iterchildren():
            result.append(splap(i))
    elif(root.tag=="checkmark"):
        return [[]]
    elif(root.tag=="mandatory_feature"):
        feature = root.get("name")
        for i in root.iterchildren():
            computation = splap(i)
            result.extend(computation)
        for i in result:
            if feature == featureP:
                i.append(feature)
            else:
                if "*" not in i:
                   i.append("*")
        return result
    elif(root.tag=="choose_1"):
        for i in root.iterchildren():
            resaux = splap(i)
            for j in resaux:
                result.append(j)
        m = map(frozenset,result)
        result = list(map(list,m))
    return result


def run(file, fea):
    """
    Run function
    """
    global featureP
    name = file
    featureP = fea
    xml = etree.parse(name)
    results = splap(xml.getroot())
    a =float(sum(x.count(featureP) for x in results[0]))
    b =float(len(results[0]))
    with open(file+".txt", "a") as myfile:
        myfile.write("Final prob of: "+featureP+" In: "+name+" Is: "+str(a/b)+"\n")

def main():
    """
    Main function
    """
    if len(sys.argv) < 2:
        print "Usage: splap_prenormal.py DATA_SPLAP/<input XML file>"
        print "The input xml file must be in pre-normal form."
        return
    source = sys.argv[1]
    e = xml.etree.ElementTree.parse(source).getroot()
    for featureP in list(e.iter()):
        if featureP.tag == 'mandatory_feature' or featureP.tag == 'optional_feature':
            run(source, featureP.get('name'))


if __name__ == "__main__":
    main()