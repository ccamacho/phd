"""
This program translate 
Betty feature models in XML in 
fodaAT input XML
"""
from lxml import etree
import os
msg = "" 


def pr(message, init = False):
    global msg
    if init:
        msg = message+"\n"+msg+"\n"
    else:
        msg = msg+message+"\n"


def ck():
    pr("<checkmark></checkmark>")


def read_betty(root,tab="\t"):
    if root.tag =="feature-model":
        for i in root.iterchildren():
            read_betty(i)
    elif root.tag =="feature":
        pr(tab+"<paralel>")
        for i in root.iterchildren():
            read_betty(i)
        pr(tab+"</paralel>")
    elif root.tag =="binaryRelation":
        min = 0
        max = 0
        nam = ""
        for j in root.iterchildren():
            if j.tag =="cardinality":
                min = j.get("min")
                max = j.get("max")
            elif j.tag=="solitaryFeature":
                nam = j.get("name")
            else:
                "Unexpected binary-relation {0}".format(j.tag)
        if (min == max):
            pr(tab+"<optional_feature name=\"{0}\">1".format(nam))
        else:
            pr(tab+"<mandatory_feature name=\"{0}\">2".format(nam))
        found = False
        for j in root.iterchildren():
            for i in j.iterchildren():
                found = True
        if not found:
            pr(tab+"<checkmark></checkmark>")
        else:
            pr("<paralel>")
            for j in root.iterchildren():
                for i in j.iterchildren():
                    read_betty(i,tab+"\t")
            pr("</paralel>")
        if (min == max):
            pr(tab+"</optional_feature>")
        else:
            pr(tab+"</mandatory_feature>")
    elif root.tag == "groupedFeature":
        pr(tab+"<mandatory_feature name=\"{0}\">".format(root.get("name")))
        found = False
        for j in root.iterchildren():
            found = True
            read_betty(j,tab+"\t")
        if not found:
            pr(tab+"<checkmark></checkmark>")
        pr(tab+"</mandatory_feature>")
    elif root.tag == "setRelation":
        pr(tab+"<choose_1>")
        for j in root.iterchildren():
            if j.tag=="cardinality":
                pass
            else:
                read_betty(j,tab+"\t")
        pr(tab+"</choose_1>")
    elif root.tag == "requires":
        pr(tab+"<requires feature_1=\"{0}\" feature_2=\"{1}\">".format(root.get("feature"),root.get("requires")),True)
        for i in root.iterchildren():
            read_betty(i)
            print "recursive requires"
        pr(tab+"</requires>")

    elif root.tag == "excludes":
        pr(tab+"<excludes feature_1=\"{0}\" feature_2=\"{1}\">".format(root.get("excludes"),root.get("feature")),True)
        for i in root.iterchildren():
            read_betty(i)
            print "recursive excludes"
        pr(tab+"</excludes>")
    else:
        print "Unexpected tag {0}".format(root.tag)


def main():
    for file in os.listdir("BETTY_DATA"):
            if file.endswith(".xml"):
                name = file
                xml = etree.parse("BETTY_DATA/"+name)
                read_betty(xml.getroot())
                text_file = open("DATA_SPLAP/"+name, "w")
                text_file.write("<xml version=\"1.0\" encoding=\"UTF-8\">\n"+ msg +"\n </xml>")
                text_file.close()

    
if __name__ == "__main__":
    print "This script will convert all BETTY xml files to fodaA syntax"
    print "Will get each file from the BETTY_DATA folder and will create the"
    print "equivalent in the DATA_SPLAP folder"
    main()
