splaAP implementation

This package contents:

1- Script to translate XML Betty feature models in fodaAT syntax.
   Usage: python translate.py
   Description: This will crawl all XML files in the BETTY_DATA folder
   and will create the equivalent file in the DATA_SPLAP folder.

2- Script to compute and calculate features probability for pre-normal terms.
   Usage: python splap_prenormal.py DATA_SPLAP/<input XML file>
   Description: This script will create a DATA_SPLAP/<input XML file>.txt file
   with the probability of each feature.

3- Script to calculate and graph features probability.
   Usage: python splap_graph_probs_sorted.py
   Description: This script will generate a EPS image in DATA_SPLAP
   for each fodaA model stored in the same DATA_SPLAP folder
   with the plot of the computed features probability, sorted descending.

4- Script to calculate and graph features computing time.
   Usage: python splap_graph_times.py
   Description: This script will generate a EPS image in DATA_SPLAP
   for each fodaA model stored in the same DATA_SPLAP folder
   with the plot of the time to compute each feature.